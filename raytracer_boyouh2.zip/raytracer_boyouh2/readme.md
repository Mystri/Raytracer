
Run with `python main.py` and input appropriate values.

Might have unintended behavior with extreme input.

**Sample arguments**

final_128_96.png: 

    
    Input image width:
    128
    Input image height:
    96
    Input samples per pixel:
    100
    Input max depth:
    50

final_400_300.png:

    Input image width:
    960
    Input image height:
    540
    Input samples per pixel:
    200
    Input max depth:
    100